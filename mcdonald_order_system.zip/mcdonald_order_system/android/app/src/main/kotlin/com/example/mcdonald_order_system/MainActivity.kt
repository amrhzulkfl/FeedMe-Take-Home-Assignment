package com.example.mcdonald_order_system

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
