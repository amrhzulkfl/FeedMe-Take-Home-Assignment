import 'dart:async';

class Order {
  final int number;
  final String type; // normal/vip order
  String status; // pending/processing/complete
  int? botId; // Add botId to track which bot processed the order

  Order(this.number, this.type, this.status, {this.botId});
}

class Bot {
  final int id;
  String status; // processing/idle
  Timer? timer;  // timer for the bot to process order
  Order? currentOrder; // Track the order currently assigned to this bot

  Bot(this.id, this.status);
}