import 'dart:async';
import 'package:flutter/material.dart';
import 'order.dart';

class OrderSystem extends StatefulWidget {
  _OrderSystemState createState() => _OrderSystemState();
}

class _OrderSystemState extends State<OrderSystem> {
  int orderNumber = 1; // unique numbers to orders
  List<Order> pendingOrders = []; // list to store pending orders
  List<Order> completedOrders = []; // list to store completed orders
  List<Bot> bots = []; // list of bots that can process orders
  int botCount = 0; // unique id to bots

  void addOrder(String type) {
    setState(() { // rebuild the UI with updated state
      final newOrder = Order(orderNumber++, type, 'PENDING');
      if (type == 'VIP') {
        int vipIndex = pendingOrders.indexWhere((order) => order.type != 'VIP'); //find index of the first non-vip order
        if (vipIndex == -1) { //if all orders in the list are vip/empty
          pendingOrders.add(newOrder); //added to the end of the list for the vips
        } else {
          pendingOrders.insert(vipIndex, newOrder); //inserted at the position of the first normal order
        }
      } else {
        pendingOrders.add(newOrder); //add normal to pendinglist
      }
      processOrders(); //asign pending orders to available bots
    });
  }

  void addBot() {
    setState(() {
      final bot = Bot(++botCount, 'IDLE'); // create new bot with a unique(botCount) & Set status to idle
      bots.add(bot); //add the new bot to the list
      processOrders(); //assign pending orders to available bots
    });
  }

  void processOrders() async {
    for (var bot in bots) { //lop through bots and assign orders to available bots
      if (bot.status == 'IDLE' && pendingOrders.isNotEmpty) {
        final order = pendingOrders.firstWhere((order) => order.status == 'PENDING'); //grabs the first pending order

        setState(() {
          order.status = 'PROCESSING';
          bot.status = 'PROCESSING';
          bot.currentOrder = order; // Assign the order to the bot
          order.botId = bot.id; //asign the order's bot id
        });

        bot.timer = Timer(Duration(seconds: 10), () { //sets up a 10-second timer
          setState(() {
            pendingOrders.remove(order); //remove the order from the pending order
            completedOrders.add(order..status = 'COMPLETE'); //add the order to the complete order and change the status to complete
            bot.status = 'IDLE'; 
            bot.currentOrder = null; // Clear the order after processing
            processOrders();
          });
        });
      }
    }
  }

  void removeBot() {
    if (bots.isNotEmpty) {
      setState(() {
        Bot lastBot = bots.removeLast();

        // Check if the bot is currently processing an order
        if (lastBot.status == 'PROCESSING' && lastBot.currentOrder != null) {
          // Cancel the timer for the bot
          lastBot.timer?.cancel();
          lastBot.currentOrder!.status = 'PENDING';  // Set the order status back to pending
          lastBot.currentOrder = null; // Clear the bot's current order
          processOrders();  // Reassign the pending orders to available bots
        }
      });
    }
  }

Widget build(BuildContext context) {
  return Scaffold(
    appBar: PreferredSize(
      preferredSize: Size.fromHeight(150.0), // Set the height of the AppBar
      child: AppBar(
        flexibleSpace: Container(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center, // Center the content vertically
            children: [
              SizedBox(height: 10),
              Image.asset(
                'assets/images/mcdlogo.png', // Replace with your image path
                height: 80, // Adjust the size of the image as needed
              ),
              Text(
                'McDonald\'s Order System',
                style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold, color: Colors.red), // Customize text style
              ),
            ],
          ),
        ),
        centerTitle: true, // Keep the title centered
      ),
    ),
      body: Column(
        children: [
          SizedBox(height: 30),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              ElevatedButton(
                onPressed: () => addOrder('Normal'),
                style: ElevatedButton.styleFrom(
                  foregroundColor: Colors.white, // Text color
                  backgroundColor: Colors.red,
                  shadowColor: Colors.black, // Shadow color
                  elevation: 5, // Elevation
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20), // Rounded corners
                  ),
                  padding: EdgeInsets.symmetric(horizontal: 32, vertical: 20), // Padding
                ),
                child: Text('New Normal Order'),
              ),
              SizedBox(width: 20),
              ElevatedButton(
                onPressed: () => addOrder('VIP'),
                style: ElevatedButton.styleFrom(
                  foregroundColor: Colors.white, backgroundColor: Colors.red, // Text color
                  shadowColor: Colors.black, // Shadow color
                  elevation: 5, // Elevation
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20), // Rounded corners
                  ),
                  padding: EdgeInsets.symmetric(horizontal: 32, vertical: 20), // Padding
                ),
                child: Text('New VIP Order'),
              ),
              SizedBox(width: 20),
              ElevatedButton(
                onPressed: addBot,
                style: ElevatedButton.styleFrom(
                  foregroundColor: Colors.red, 
                  backgroundColor: const Color.fromARGB(255, 255, 186, 59), // Text color
                  shadowColor: Colors.black, // Shadow color
                  elevation: 5, // Elevation
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20), // Rounded corners
                  ),
                  padding: EdgeInsets.symmetric(horizontal: 32, vertical: 20), // Padding
                ),
                child: Text('+ Bot'),
              ),
              SizedBox(width: 20),
              ElevatedButton(
                onPressed: removeBot,
                style: ElevatedButton.styleFrom(
                  foregroundColor: Colors.red, 
                  backgroundColor: const Color.fromARGB(255, 255, 186, 59), // Text color
                  shadowColor: Colors.black, // Shadow color
                  elevation: 5, // Elevation
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20), // Rounded corners
                  ),
                  padding: EdgeInsets.symmetric(horizontal: 32, vertical: 20), // Padding
                ),
                child: Text('- Bot'),
              ),
            ],
          ),
          SizedBox(height: 30),
          Expanded(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                buildPendingOrderColumn('Pending Order', pendingOrders),
                buildCompletedOrderColumn('Completed Order', completedOrders),
                buildBotColumn(),
              ],
            ),
          ),
        ],
      ),
    );
  }

Widget buildPendingOrderColumn(String title, List<Order> orders) {
  return Expanded(
    child: Padding(
      padding: const EdgeInsets.all(16.0), // Add padding around the entire section
      child: Container(
        decoration: BoxDecoration(
          color: const Color.fromARGB(255, 255, 255, 255), // Background color for the entire section
          borderRadius: BorderRadius.circular(15), // Rounded corners for the section container
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.2), // Shadow effect
              spreadRadius: 2,
              blurRadius: 5,
              offset: Offset(3, 3), // Shadow positioning
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start, // Align the content to the left
          children: [
            Container(
            decoration: BoxDecoration(
              color: Colors.red, // Set your background color here
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(15),
                topRight: Radius.circular(15),
              ),
            ),
            child:Padding(
              padding: const EdgeInsets.all(16.0), // Padding for the title
              child:Center(
              child: Text(
                '${title} (${orders.length})',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.white),
              ),
            ),
            ),
            ),
            Expanded(
              child: ListView.builder(
                itemCount: orders.length,
                itemBuilder: (context, index) {
                  return Padding(
                    padding: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0), // Padding around each list item
                    child: Container(
                      decoration: BoxDecoration(
                        color: Colors.yellow.shade100, // Set a background color for each order
                        borderRadius: BorderRadius.circular(15), // Rounded corners for each order
                        boxShadow: [
                          BoxShadow(
                            color: Colors.grey.withOpacity(0.2), // Shadow color
                            spreadRadius: 1,
                            blurRadius: 5,
                            offset: Offset(2, 4), // Shadow positioning
                          ),
                        ],
                      ),
                      child: ListTile(
                        contentPadding: EdgeInsets.symmetric(vertical: 10.0, horizontal: 16.0), // Padding inside ListTile
                        title: Text(
                          '${orders[index].type} Order #${orders[index].number}',
                          style: TextStyle(fontSize: 18, fontWeight: FontWeight.w500),
                        ),
                        subtitle: Text(
                          orders[index].status,
                          style: TextStyle(color: Colors.grey.shade700),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    ),
  );
}

Widget buildCompletedOrderColumn(String title, List<Order> orders) {
  return Expanded(
    child: Padding(
      padding: const EdgeInsets.all(16.0), // Add padding around the entire section
      child: Container(
        decoration: BoxDecoration(
          color: const Color.fromARGB(255, 255, 255, 255), // Background color for the entire section
          borderRadius: BorderRadius.circular(15), // Rounded corners for the section container
          //border: Border.all(color: Colors.orange, width: 2), // Border for the section container
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.2), // Shadow effect
              spreadRadius: 2,
              blurRadius: 5,
              offset: Offset(3, 3), // Shadow positioning
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start, // Align the content to the left
          children: [
            Container(
            decoration: BoxDecoration(
              color: Colors.red, // Set your background color here
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(15),
                topRight: Radius.circular(15),
              ),
            ),
            child:Padding(
              padding: const EdgeInsets.all(16.0), // Padding for the title
              child: Center(
              child: Text(
                '${title} (${orders.length})',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.white),
              ),
              ),
            ),
            ),
            Expanded(
              child: ListView.builder(
                itemCount: orders.length,
                itemBuilder: (context, index) {
                  return Padding(
                    padding: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0), // Padding around each list item
                    child: Container(
                      decoration: BoxDecoration(
                        color: const Color.fromARGB(255, 196, 255, 214), // Set a background color for each order
                        borderRadius: BorderRadius.circular(15), // Rounded corners for each order
                        //border: Border.all(color: const Color.fromARGB(255, 72, 220, 32), width: 2), // Border for each order
                        boxShadow: [
                          BoxShadow(
                            color: Colors.grey.withOpacity(0.2), // Shadow color
                            spreadRadius: 1,
                            blurRadius: 5,
                            offset: Offset(2, 4), // Shadow positioning
                          ),
                        ],
                      ),
                      child: ListTile(
                        contentPadding: EdgeInsets.symmetric(vertical: 10.0, horizontal: 16.0), // Padding inside ListTile
                        title: Text(
                          '${orders[index].type} Order #${orders[index].number}',
                          style: TextStyle(fontSize: 18, fontWeight: FontWeight.w500),
                        ),
                        subtitle: Text(
                          '${orders[index].status} BY BOT #${orders[index].botId}',
                          style: TextStyle(color: Colors.grey.shade700),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    ),
  );
}

  Widget buildBotColumn() {
    return Expanded(
      child: Padding(
      padding: const EdgeInsets.all(16.0), // Add padding around the entire section
      child: Container(
        decoration: BoxDecoration(
          color: const Color.fromARGB(255, 255, 255, 255), // Background color for the entire section
          borderRadius: BorderRadius.circular(15), // Rounded corners for the section container
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.2), // Shadow effect
              spreadRadius: 2,
              blurRadius: 5,
              offset: Offset(3, 3), // Shadow positioning
            ),
          ],
        ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            decoration: BoxDecoration(
              color: const Color.fromARGB(255, 255, 186, 59), // Set your background color here
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(15),
                topRight: Radius.circular(15),
              ),
            ),
            child: Padding(
              padding: const EdgeInsets.all(16.0), // Padding for the title
              child: Center(
                child: Text(
                  'Bots (${bots.length})',
                  style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color:Colors.red),
                ),
              ),
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: bots.length,
              itemBuilder: (context, index) {
                return ListTile(
                  title: Text('Bot #${bots[index].id}'),
                  subtitle: Text(bots[index].status, style: TextStyle(color: Colors.grey.shade700)),
                );
              },
            ),
          ),
        ],
      ),
      ),
      ),
    );
  }
}