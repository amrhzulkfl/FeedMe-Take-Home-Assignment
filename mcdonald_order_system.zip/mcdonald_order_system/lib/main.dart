import 'package:flutter/material.dart';
import 'order_system.dart';

void main() {
  runApp(McDonaldsOrderSystem());
}

class McDonaldsOrderSystem extends StatelessWidget {
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'McDonald\'s Order System',
      theme: ThemeData(
        fontFamily: 'Poppins',
      ),
      home: OrderSystem(),
    );
  }
}